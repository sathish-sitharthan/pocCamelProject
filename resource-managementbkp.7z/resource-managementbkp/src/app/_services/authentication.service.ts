﻿import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable()
export class AuthenticationService {
    constructor(private http: HttpClient) { }

   login(username: string, password: string) {

		
        let headers: HttpHeaders = new HttpHeaders();
		headers = headers.append('Content-Type', 'application/json');
		headers = headers.append('Accept-API-Version', 'resource=1.0, protocol=2.1');
		headers = headers.append('X-OpenAM-Username', username);
		headers = headers.append('X-OpenAM-Password', password);
		
        return this.http.post<any>(`http://local.connectme.us:8082/openam/json/realms/root/authenticate`, {},{headers})      
            .pipe(map(data => {				
                // login successful if there's a jwt token in the response
                if (data && data.tokenId) {		
					var key = "username";
					var newVal = username;
					data[key] = newVal;						              
                    localStorage.setItem('currentUser', JSON.stringify(data));
                }
                return data;
            }));
    }

    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
    }
}