﻿import { Injectable } from '@angular/core';
import { HttpClient , HttpHeaders} from '@angular/common/http';

import { User, App } from '../_models';

@Injectable({ providedIn: 'root' })
export class AppService {
     currentUser: User;
     constructor(private http: HttpClient) { 
	 this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
	}

    getAllApps() {
       return this.http.get<any>('http://local.connectme.us:8081/openig/api/system/objects/_router/routes?_queryFilter=true'); 
    }

    createApp(am: App) {       
		 var url = "http://local.connectme.us:8081/openig/api/system/objects/_router/routes/" + am.id;
		 var host = am.url.replace(/(^\w+:|^)\/\//, '');		
		 var json = {
		  "name": am.name,
		  "baseURI": am.url,
		  "condition": "${matches(request.uri.condition, '^" + am.path + "')}",
		  "capture": ["response","request"],
		  "heap":[ 
			  { 
				 "name":"AmService-1",
				 "type":"AmService",
				 "config":{ 
					"url":"http://local.connectme.us:8082/openam",
					"realm":"/",
					"ssoTokenHeader":"iPlanetDirectoryPro",
					"agent":{ 
					   "username":"ig_agent",
					   "password":"password"
					},
					"sessionCache":{ 
					   "enabled":false
					}
				 }
			  }
			],
		  "handler": {
			"type": "Chain",			
			"config": {
			  "filters": [
					 { 
               "name":"HostHeaderFilter",
               "type":"HeaderFilter",
               "config":{ 
                  "messageType":"REQUEST",
                  "remove":[ 
                     "host"
                  ],
                  "add":{ 
                     "Host":[ 
                        "/yeast2"
                     ]
                  }
               }
            },
            { 
               "name":"SingleSignOnFilter-1",
               "type":"SingleSignOnFilter",
               "config":{ 
                  "amService":"AmService-1"
               }
            },
            { 
               "name":"HeaderFilter-LegacyHeaderFilter-1",
               "type":"HeaderFilter",
               "config":{ 
                  "messageType":"REQUEST",
                  "add":{ 
                     "X-IG-SessionInfo":[ 
                        "username: ${contexts.ssoToken.info.uid}, realm: ${contexts.ssoToken.info.realm}"
                     ]
                  }
               }
            },
            { 
               "name":"PolicyEnforcementFilter-1",
               "type":"PolicyEnforcementFilter",
               "config":{ 
                  "pepRealm":"/",
                  "application":"protectedResources",
                  "ssoTokenSubject":"${contexts.ssoToken.value}",
                  "amService":"AmService-1"
               }
            },
			{
			  "name": "HeaderFilter-Injectusername-1",
			  "type": "HeaderFilter",
			  "config": {
				"messageType": "REQUEST",
				"add": {
				  "IG-UserName": [
					"${contexts.userProfile.username}"
				  ]
				}
			  }
			}
			  ],
			  "handler": "ReverseProxyHandler"
			}
		  }
		}
		
		let headers: HttpHeaders = new HttpHeaders();
		headers = headers.append('Content-Type', 'application/json');
		headers = headers.append('Accept-API-Version', 'resource=1.0, protocol=2.1');		
		headers = headers.append('iPlanetDirectoryPro', this.currentUser.tokenId);	
		return this.http.put<any>(url,json,{headers: headers});		
		
	}
	
	createPolicy(am: App) {  
		var policyjson = {
			"name":am.name,
			"active":true,
			"description":am.name,
			"applicationName":"iPlanetAMWebAgentService",
			"actionValues":{
				"POST":false,
				"GET":true
			},
			"resources":[				
				  am.urlpattern
			],
			"subject":{
				"type":"AuthenticatedUsers"
			},			
			"lastModifiedBy":"id=amadmin,ou=user,dc=openam,dc=forgerock,dc=org",
			"lastModifiedDate":"2015-05-11T14:48:08.711Z",
			"createdBy":"id=amadmin,ou=user,dc=openam,dc=forgerock,dc=org",
			"creationDate":"2015-05-11T14:48:08.711Z"
		}
			
				
		let headers: HttpHeaders = new HttpHeaders();
		headers = headers.append('Content-Type', 'application/json');
		headers = headers.append('Accept-API-Version', 'resource=1.0, protocol=2.1');		
		headers = headers.append('iPlanetDirectoryPro', this.currentUser.tokenId);				
		return this.http.post<any>('http://local.connectme.us:8082/openam/json/realms/root/policies?_action=create',policyjson,{headers: headers});
	}

}