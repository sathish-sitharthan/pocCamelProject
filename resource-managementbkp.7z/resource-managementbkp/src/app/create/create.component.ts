﻿import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { AlertService, UserService ,AppService} from '../_services';

@Component({templateUrl: 'create.component.html'})
export class CreateComponent implements OnInit {
    createForm: FormGroup;
    loading = false;
    submitted = false;

    constructor(
        private formBuilder: FormBuilder,
        private router: Router,
        private userService: UserService,	
		private appService: AppService,		
        private alertService: AlertService) { }

    ngOnInit() {
        this.createForm = this.formBuilder.group({
			integration: ['', Validators.required],
            id: ['', Validators.required],
            name: ['', Validators.required],
            url: ['', Validators.required],
			path: ['', Validators.required],
			sso: ['', Validators.required],
			authorization: ['', Validators.required],
			usercontext: ['', Validators.required],
			mfa: ['', Validators.required],
			transauth: ['', Validators.required],			
			groups: [''],
			urlpattern: ['']
			
        });
    }

    // convenience getter for easy access to form fields
    get f() { return this.createForm.controls; }

    onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.createForm.invalid) {			
            return;
        }
		
        this.loading = true;
        this.appService.createApp(this.createForm.value)
           
           .subscribe(
                data => {					
                    this.appService.createPolicy(this.createForm.value)
	   
				   .subscribe(
						data => {					
							this.alertService.success('Resource Created', true);
							this.router.navigate(['/']);
						},
						error => {
							alert("hi Error");
							this.alertService.error(error);
							this.loading = false;
						});
                },
                error => {
					alert("hi Error");
                    this.alertService.error(error);
                    this.loading = false;
                });
	  
    }
}
