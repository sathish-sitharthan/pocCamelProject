﻿export class App {  
	
    id : string;
	name : string;
	url: string;
	path: string;
	urlpattern: string;
	groups : string;
	
}