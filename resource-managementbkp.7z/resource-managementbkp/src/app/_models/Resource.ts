﻿export class Resource {  
	
    _id: string;
	name: string;
	baseURI: string;
	condition: string;
	
}