﻿import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';
import { User , Resource} from '../_models';
import { UserService , AppService } from '../_services';

@Component({templateUrl: 'home.component.html'})
export class HomeComponent implements OnInit {
    currentUser: User;
    users: User[] = [];
	resources: Resource[] = [];
	apps = [
		{ "_id": "test1", "name": "test desc1", "baseURI": "test desc1", "condition": "test desc1" }
	];			  
	
	columnDefs = [
        { headerName: 'ID', field: '_id', sortable: true, filter: true },
        { headerName: 'NAME', field: 'name', sortable: true, filter: true },
		{ headerName: 'URL', field: 'baseURI', sortable: true, filter: true },
		{ headerName: 'PATH', field: 'condition', sortable: true, filter: true }
    ];

    constructor(private userService: UserService, private appService: AppService) {
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));		
    }

    ngOnInit() {
        this.loadResources();
    }  
	
	private loadResources() {
        this.appService.getAllApps()
            .subscribe(
                data => {
                  // this.apps = data.result;				  
                },
                error => {
                    console.log(error);
                });
    }	
	
}